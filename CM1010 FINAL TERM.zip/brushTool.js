function brushTool() {
    //set an icon and a name for the object
    this.icon = "assets/brushTool.png";
    this.name = "brushTool";

    var fillMouseX = -1;
    var fillMouseY = -1;

    this.populateOptions = function () {
        // click handler
        //set this button to inform people that this application 
        //cannot do the color mixture work.
        select("#okButton").mouseClicked(function () {
            alert("Choose One Color Each Time!")
            background(255, 255, 255);
            loadPixels();
            okButton.style.display = "none";
        });
    }

    this.draw = function () {
        //if the mouse is pressed
        if (mouseIsPressed) {
            //check if they fillX and Y are -1. set them to the current mouse X and Y if they are.
            if (fillMouseX == -1) {
                fillMouseX = mouseX;
                fillMouseY = mouseY;

            }
            //if we already have values for fillX and Y we can draw a line from there to the current mouse location
            //continuously draw filled ellipse to fill the shapes, ellipse size can be changed by control slider. 
            else {
                fill(colourP.selectedColour); // change colour by colour palette.
                stroke(colourP.selectedColour);
                ellipse(fillMouseX, fillMouseY, penSizeSlider.value(), penSizeSlider.value());
                fillMouseX = mouseX;
                fillMouseY = mouseY;
            }
        }
        //if the user has released the mouse we want to set the fillMouse values 
        //back to -1.
        else {

            fillMouseX = -1;
            fillMouseY = -1;
        }

    };
}
