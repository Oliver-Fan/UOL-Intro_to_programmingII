function ScissorTool(){

    this.icon = "assets/scissorsTool.png";
    this.name = "ScissorsTool";

    var selectMode = 1;
    var selectedArea = {x: 0, y:0, w: 0, h: 0};

    var previousMouseX = -1;
    var previousMouseY = -1;

    var selectedPixels;

    this.draw = function(){
     
    }

    this.mousePressed = function(){

        //press in the canvas
        if(mouseY<=getCurrentCanvasHeight()){
            console.log("in canvas");
            if(selectMode == 1)//select area mode
            {
                if (previousMouseX == -1)
                {
                    previousMouseX = mouseX;
                    previousMouseY = mouseY;
                    selectedArea = {x: mouseX, y:mouseY, w: 0, h: 0};
                }
            }
            else if(selectMode == 2)//paste mode
            {
                image(selectedPixels, mouseX, mouseY);
                loadPixels();
            }
        }
    }
    
    this.mouseMoved = function(){
        if(selectMode == 2)//paste mode
        {
            //save the current canvas
            updatePixels();
            //draw the temp windows
            fill(0,0,125,125)
            rect(mouseX+5,mouseY+5,selectedArea.w-10,selectedArea.h-10);
        }
        
    }

    this.mouseDragged = function(){
        
        //if out of canvas dont do anything
        if(mouseY>=getCurrentCanvasHeight()){
            return;
        }
        
        if(selectMode == 1)//select area mode
        {
            updatePixels();

            var w = mouseX - selectedArea.x;
            var h = mouseY - selectedArea.y;

            selectedArea.w = w;
            selectedArea.h = h;
            noStroke();
            fill(255,0,0,100);
            rect(selectedArea.x, selectedArea.y, selectedArea.w, selectedArea.h);
        }
    }
    
    this.mouseReleased = function(){
        if(selectMode == 1){
            showScissorButton();
        }
        else if(selectMode==2){
            previousMouseX = -1;
            previousMouseY = -1;
        }
    }

    //when the tool is deselected update the pixels to just show the drawing and
    //hide the line of symmetry. Also clear options
    this.unselectTool = function() {
        updatePixels();
        //clear options
        select(".options").html("");

        //set back the default fill and stroke colour
        fill(colourP.selectedColour);
        stroke(colourP.selectedColour);

        //reset to starting
        selectedArea = {x: 0, y:0, w: 0, h: 0};
        previousMouseX = -1;
        selectMode = 1;
        previousMouseX = -1;
        previousMouseY = -1;
        selectedPixels = null;
    };

    function scissorButtonClicked(){
        if(selectMode==1){
            selectMode = 2;
            //show button
            showScissorButton();
            //lable button to End Paste
            select("#scissorButton").html("End Paste");
            cutClicked();
        }
        else if(selectMode==2){
            selectMode = 1;
            //hide button
            hideScissorButton();
            //label button to Cut
            select("#scissorButton").html("Cut");
            pasteClicked();
            previousMouseX = -1;
        }
    }

    function cutClicked(){
        console.log("cut clicked");
        updatePixels();
        console.log(selectedArea);
        //store the pixels
        processSelectedArea();
        console.log(selectedArea);
        selectedPixels = get(selectedArea.x , selectedArea.y , selectedArea.w, selectedArea.h);

        //draw a rectangle over it
        fill(255);
        noStroke();
        rect(selectedArea.x, selectedArea.y, selectedArea.w, selectedArea.h);
        loadPixels();
    }
    
    function processSelectedArea(){
        if(selectedArea.w<0){
            selectedArea.w = abs(selectedArea.w);
            selectedArea.x -= selectedArea.w;
        }
         
        if(selectedArea.h<0){
            selectedArea.h = abs(selectedArea.h);
            selectedArea.y -= selectedArea.h;
        }
    }
    

    function getCurrentCanvasHeight(){
        var canvasContainer = select('#content');
        var drawingCanvasHeight = canvasContainer.size().height;   
        return drawingCanvasHeight;
    }
    // action for paste
    function pasteClicked(){
        loadPixels();
    }
//show button
    function showScissorButton(){
        var cutButton = document.getElementById("scissorButton");
        cutButton.style.visibility = "visible";
    }
//hide button
    function hideScissorButton(){
        var cutButton = document.getElementById("scissorButton");
        cutButton.style.visibility = "hidden";
    }

    this.populateOptions = function() {
        select(".options").html("<button style='visibility:hidden' id='scissorButton'>Cut</button>");
        select("#scissorButton").mouseClicked(scissorButtonClicked);
    }
}